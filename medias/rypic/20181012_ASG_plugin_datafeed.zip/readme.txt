-----------------------------------------------------------------------------------------------------------------------------
Installation

1.   Please create the following directories for the both datafeed and plugin to generate their log files.
     D:\Log\MT4\Plugin\
     D:\Log\MT4\Plugin\old_logs\
     D:\Log\MT4\Datafeed\
     D:\Log\MT4\Datafeed\old_logs\

2.   Please place all files extracted from the zip into the MetaTrader 4 Server corresponding directories.

3.   Datafeed: 
     - "Login" and "Password" will be automatically filled when the datafeed file is selected.
     - The Idle timeout cannot be set too short. It is necessary to reserve time for the datafeed to authenticate with the quote server when it starts or reconnects.

4.   Plugin:
     - Please configure the plugin route setting. ("MetaTrader 4 Administrator" -> "Plugins")
	 - Route Group List (,)
	 - Route Symbol List (,)

5.   Please ensure the plugin has been enabled.
     Please restart the MetaTrader 4 Server to ensure the plugin is completely loaded by the MT server.

-----------------------------------------------------------------------------------------------------------------------------
Watchdog (if it is installed for setup MT backup server):

1.   X:\MetaTrader4Server\config\mtwdsrv.ini
     Please add the following 4 lines in backup server's mtwdsrv.ini file in order to synchronize all plugin and datafeed resources to the backup server completely.

Folder=datafeed;*.cfg
Folder=plugins;*.ini.*
Folder=plugins\OpenSSL;*.*
Folder=plugins\ManagerAPI;*.*
